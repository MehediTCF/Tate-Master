package TateMaster;

import java.awt.Color;
import java.awt.Graphics;

public class Paddle
{

	public int paddleNo;
 
	public int x, y, width = 20, height = 150;

	public int score;

	public Paddle(Pong pong, int paddleNo)
	{
		this.paddleNo = paddleNo;

		if (paddleNo == 1)
		{
			this.x = 10;
		}

		if (paddleNo == 2)
		{
			this.x = pong.width - width-10;
		}

		this.y = pong.height / 2 - this.height / 2;
	}

	public void render(Graphics g)
	{
		g.setColor(Color.pink);
		g.fillRect(x, y, width, height);
	}

	public void move(boolean up)
	{
		int speed = 20;

		if (up)
		{
			if (y - speed > 0)
			{
				y -= speed;
			}
			else
			{
				y = 0;
			}
		}
		else
		{
			if (y + height + speed < Pong.pong.height)
			{
				y += speed;
			}
			else
			{
				y = Pong.pong.height - height;
			}
		}
	}

}