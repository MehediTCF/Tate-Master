package TateMaster;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Ball
{

	public int x, y, width = 22, height = 22;

	public int mX, mY;

	public Random random;

	private Pong pong;

	public int amountOfHits;
        SoundPlayer s2 = new SoundPlayer("/TateMaster/sounds/Shoteffect.mp3");
        SoundPlayer s4 = new SoundPlayer("/TateMaster/sounds/Accept.mp3");

	public Ball(Pong pong)
	{
		this.pong = pong;

		this.random = new Random();

		spawn();
	}

	public void update(Paddle paddle1, Paddle paddle2)
	{
		int spd = 5;

		this.x += mX * spd;
		this.y += mY * spd;

		if (this.y + height - mY > pong.height || this.y + mY < 0)
		{
			if (this.mY < 0)
			{
				this.y = 0;
				this.mY = random.nextInt(4);

				if (mY == 0)
				{
					mY = 1;
				}
			}
			else
			{
				this.mY = -random.nextInt(4);
				this.y = pong.height - height;

				if (mY == 0)
				{
					mY = -1;
				}
			}
		}

		if (Collision(paddle1) == 1)
		{
			this.mX = 1 + (amountOfHits / 5);
			this.mY = -2 + random.nextInt(4);

			if (mY == 0)
			{
				mY = 1;
			}
                        s2.play();

			amountOfHits++;
		}
		else if (Collision(paddle2) == 1)
		{
			this.mX = -1 - (amountOfHits / 5);
			this.mY = -2 + random.nextInt(4);

			if (mY == 0)
			{
				mY = 1;
			}
                        s2.play();

			amountOfHits++;
                        
		}

		if (Collision(paddle1) == 2)
		{
			paddle2.score++;
                        s4.play();
			spawn();
		}
		else if (Collision(paddle2) == 2)
		{
			paddle1.score++;
                        s4.play();
			spawn();
		}
	}

	public void spawn()
	{
		this.amountOfHits = 0;
		this.x = pong.width / 2 - this.width / 2;
		this.y = pong.height / 2 - this.height / 2;

		this.mY = -2 + random.nextInt(6);

		if (mY == 0)
		{
			mY = 1;
		}

		if (random.nextBoolean())
		{
			mX = 1;
		}
		else
		{
			mX = -1;
		}
	}

	public int Collision(Paddle paddle)
	{
		if (this.x < paddle.x + paddle.width && this.x + width > paddle.x && this.y < paddle.y + paddle.height && this.y + height > paddle.y)
		{
			return 1; //bounce
		}
		else if ((paddle.x > x && paddle.paddleNo == 1) || (paddle.x < x - width && paddle.paddleNo == 2))
		{
			return 2; //score
		}

		return 0; //nothing
	}

	public void render(Graphics g)
	{
		g.setColor(Color.red);
		g.fillOval(x, y, width, height);
	}

}